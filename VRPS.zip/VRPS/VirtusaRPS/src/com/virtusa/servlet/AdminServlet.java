package com.virtusa.servlet;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.*;
import com.virtusa.dao.*;
import com.virtusa.service.AdminService;
@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Logger log=Logger.getLogger(AdminServlet.class);
		 PropertyConfigurator.configure("log4j.properties");
        
		try{
			 PrintWriter out = response.getWriter();  
		    String n=request.getParameter("eid");  
		    String p=request.getParameter("password");  
		    AdminService as=new   AdminService();      
		    int r=as.login(n,p);
		    if(r!=0)
		    {	try {
		    	response.sendRedirect("AdminServ.html");
		    	}catch(Exception e) {
		    		log.fatal(e);
		    }
		    	
		    }
		    else
		    {
		    	log.info("invalid details");
		    }
		    out.close();  
		 }catch(Exception e) {
			 log.fatal(e);
		 }
		}  
}