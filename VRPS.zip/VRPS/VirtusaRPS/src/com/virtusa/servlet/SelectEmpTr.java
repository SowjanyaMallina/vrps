package com.virtusa.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


@WebServlet("/SelectEmpTr")
public class SelectEmpTr extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 Logger log=Logger.getLogger(SelectEmpTr.class);
		 PropertyConfigurator.configure("log4j.properties");
		try {
			PrintWriter pw = response.getWriter();

			Connection con= Connect.getConnection();
			try {
			
			PreparedStatement	ps = con.prepareStatement("select *from  applications where skills='java'");
			     
		        ResultSet rs=ps.executeQuery();
		        pw.println("Employees who are selected in Technical round");
			while(rs.next()) {
		
			
				pw.println("Name of Employee :"+rs.getString(1));
			      pw.println("Skills of Employee:"+rs.getString(2));
				  pw.println("Current Designation  :"+rs.getString(3));
	              pw.println("Percentage of Employee:"+rs.getInt(4));
	              pw.println("___________________________________________");
				}
			}catch (Exception e)
			{
				log.fatal(e);
			}
		}
			catch (Exception e)
			{
				
				log.fatal(e);
		     }
			
	   
		}
			
	}


