package com.virtusa.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


@WebServlet("/SelectEmp")
public class SelectEmp extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 Logger log=Logger.getLogger(SelectEmp.class);
		 PropertyConfigurator.configure("log4j.properties");
		try {
			PrintWriter pw = response.getWriter();
			Connection con=Connect.getConnection();
			PreparedStatement   ps;
			
				ps = con.prepareStatement("select *from  applications where percentage>65");
			     
		        ResultSet rs=ps.executeQuery();
		        pw.println("Employee whose pecentage is greater than 65 is selected");

			while(rs.next()) {
				pw.println("Name of Employee :"+rs.getString(1));
			      pw.println("Skills of Employee:"+rs.getString(2));
				  pw.println("Current Designation  :"+rs.getString(3));
	              pw.println("Percentage of Employee:"+rs.getInt(4));
	              
				}
			}
			
			catch (Exception e)
			{
				
			log.fatal(e);
		     }
			
	   
		}
			
		}

