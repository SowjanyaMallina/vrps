package com.virtusa.servlet;

import java.sql.Connection;
import java.sql.DriverManager;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Connect {
	public static Connection getConnection() {
		Logger log=Logger.getLogger(Connect.class);
		 PropertyConfigurator.configure("log4j.properties");
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","tiger");
		}catch(Exception e){
			log.fatal(e);
		}
		return con;
		
	}
}
