package com.virtusa.servlet;
import com.virtusa.dao.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.Applications;
@WebServlet("/Ratings")
public class Ratings extends HttpServlet {
	@Override	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	  String rate=request.getParameter("rate");  
	  Logger log=Logger.getLogger(Ratings.class);
		 PropertyConfigurator.configure("log4j.properties");
	    RatingDao ad=new RatingDao();
	    try {
	    	 PrintWriter pw = response.getWriter();
	 	    ViewEmpDao ve=new ViewEmpDao();
	 		  List<Applications> resList= ve.viewEmp();
	 		  for(int i=0;i<resList.size();i++)
	 		  {
	 			
	 			  pw.println("<h1>Ratings/Comments</h1>");

	 			  pw.println("<form>");
	 			  pw.println("<input type='checkbox' >Excellent<br>");
	 			  pw.println(" <input type='checkbox'> Good<br>");
	 			  pw.println(" <input type='checkbox'>Average<br>");
	 		      pw.println(" <input type='checkbox'>Average<br><br>");
	 			  pw.println(" <input type='submit' value='Submit'>");
	 			  pw.println("<form/>");
	 			  
	 		  }	
	 	    if(ad.giveRate(rate))
	 	    {
	 	    	pw.println("Rating is given sucessfully");
	 	    	
	 	    }

	    }catch(Exception e) {
	    	log.fatal(e);
	    }
	   
	   
	}
}

