package com.virtusa.service;
import com.virtusa.bean.*;
import com.virtusa.dao.*;


public class AdminService 
{
	 public int login(String u , String p)
  {
		 if(AdminDao.checkData(u, p))
		 {
		
	      return 1;
		 }
		 else
		 {
			 return 0;
		 }
  }
}
