package com.virtusa.service;
import com.virtusa.dao.TrDao;

public class TrService {
	 public int login(String u , String p)
	  {
			 if(TrDao.checkData(u, p))
			 {
			
		      return 1;
			 }
			 else
			 {
				 return 0;
			 }
	  }
	}

