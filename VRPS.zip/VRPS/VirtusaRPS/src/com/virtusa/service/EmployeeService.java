package com.virtusa.service;


import com.virtusa.dao.EmployeeDao;

public class EmployeeService {
	 public int login(String u , String p)
	  {
			 if(EmployeeDao.checkData(u, p))
			 {
		      return 1;
			 }
			 else
			 {
				 return 0;
			 }
	  }
}
