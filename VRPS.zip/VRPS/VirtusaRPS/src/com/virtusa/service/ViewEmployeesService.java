package com.virtusa.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.bean.Applications;
import com.virtusa.dao.ViewEmpDao;
@WebServlet("/ViewEmployeesService")
public class ViewEmployeesService extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    ViewEmpDao ve=new ViewEmpDao();
		   List<Applications> resList= ve.viewEmp();
		   PrintWriter pw = response.getWriter();
		  for(Applications a:resList)
		  {
			  pw.println("List of Employees you have applied for job");
			  pw.println("**********************************************");
			  pw.println("Application Id  "+a.getAid());
		      pw.println("Name of Employee :"+a.getName());
			  pw.println("Current Designation  :"+a.getCurrentdesg());
              pw.println("Percentage of Employee:"+a.getPercentage());
              pw.println("Skills of Employee:"+a.getSkills());
              

			  
	 
		  }	
	}

}
