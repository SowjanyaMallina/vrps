package com.virtusa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.servlet.*;
public class TrDao {
public static boolean checkData(String user,String pass) {
		Logger log=Logger.getLogger(TrDao.class);
		 PropertyConfigurator.configure("log4j.properties");
		Connection con=Connect.getConnection();
		PreparedStatement   ps;
		log.info(con);
		try {
			ps = con.prepareStatement("select * from tr where eid=? and password=?");
			ps.setString(1,user);
			ps.setString(2,pass);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				return true;
			}
		} catch (Exception e) {
			log.fatal(e);
		}

		return false;
		
	}
}
