package com.virtusa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.virtusa.servlet.Connect;
public class ApplicationDao {
	public boolean applyForPosition(String name,String skills,String currentdesg,int percentage)
	{
		 Logger log=Logger.getLogger(ApplicationDao.class);
		 PropertyConfigurator.configure("log4j.properties");
		Connection con=Connect.getConnection();
		log.info(con);
		try {
			PreparedStatement ps = con.prepareStatement("insert into applications values(?,?,?,?)");
			ps.setString(1,name);
			ps.setString(2,skills);
			ps.setString(3,currentdesg);
			ps.setInt(4,percentage);
			int rs=ps.executeUpdate();
			if(rs>0) {
				return true;
			}
		} catch (Exception e)
		{
			
			log.fatal(e);
	     }
		
		return false;
   
}
}