package com.virtusa.dao;
import com.virtusa.servlet.*;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
public class EmployeeDao {
	
	public static boolean checkData(String user,String pass) {
		 Logger log=Logger.getLogger(EmployeeDao.class);
		 PropertyConfigurator.configure("log4j.properties");
		Connection con=Connect.getConnection();
		 log.info(con);
		try {
		
			try(PreparedStatement ps = con.prepareStatement("select * from employee where eid=? and password=?")){
			ps.setString(1,user);
			ps.setString(2,pass);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				return true;
			}
			}
			} catch (SQLException e) {
			
			log.fatal(e);
		}

		return false;
		
	}
}