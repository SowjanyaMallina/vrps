package com.virtusa.dao;
import com.virtusa.bean.*;
import com.virtusa.servlet.Connect;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class ViewEmpDao {
	public List<Applications> viewEmp()
	{
		Logger log=Logger.getLogger(ViewEmpDao.class);
		 PropertyConfigurator.configure("log4j.properties");
		List<Applications> appList = new ArrayList<>();
		 try {
		Connection con=Connect.getConnection();
		PreparedStatement   ps= con.prepareStatement("select *from application");
			
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
			
				appList.add(new Applications(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5)));
				
			}
		} catch (Exception e)
		{
			
			log.fatal(e);
	     }
		
		return appList;
   
}
}
