package com.virtusa.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.servlet.*;
public class HrDao {
	public static boolean checkData(String user,String pass) {
		Logger log=Logger.getLogger(HrDao.class);
		 PropertyConfigurator.configure("log4j.properties");
		boolean b=false;
		Connection con=Connect.getConnection();
		PreparedStatement   ps;
		log.info(con);
		try {
		
			ps = con.prepareStatement("select * from hr where eid=? and password=?");
			ps.setString(1,user);
			ps.setString(2,pass);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				b=true;
			}
		} catch (SQLException e) {
			log.fatal("login");
		}
		
		
		return b;
		
	}
}
