package com.virtusa.dao;
import com.virtusa.servlet.*;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class AdminDao  {	
	public static boolean checkData(String user,String pass) {
		 Logger log=Logger.getLogger(AdminDao.class);
		 PropertyConfigurator.configure("log4j.properties");
		boolean b=false;
		Connection con=Connect.getConnection();

	log.info(con);
		try {
			
			 
			PreparedStatement   ps = con.prepareStatement("select * from admin where eid=? and password=?");
			ps.setString(1,user);
			ps.setString(2,pass);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				b= true;
			}
		} catch (SQLException e) {
			
		log.fatal("message");
		}return b;
		
	}
	
}