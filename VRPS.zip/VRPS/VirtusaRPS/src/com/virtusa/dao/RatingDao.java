package com.virtusa.dao;
import com.virtusa.servlet.Connect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
public class RatingDao {

		
		public boolean giveRate(String rate)
		{
			Logger log=Logger.getLogger(RatingDao.class);
			 PropertyConfigurator.configure("log4j.properties");
			Connection con=Connect.getConnection();
			try {
				PreparedStatement ps = con.prepareStatement("insert into ratings values(?)");
				ps.setString(1,rate);
				ResultSet rs=ps.executeQuery();
				if(rs.next()) {
					return true;
				}
			} catch (SQLException e)
			{
				
				log.fatal("hi");
		     }
			
			return false;
	   
	}
	}

