package com.virtusa.bean;



import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;



@WebServlet("/HrBean")
public class HrBean extends HttpServlet {
	private String eId;
	private String password;
	private int ratings;
	public String geteId() {
		return eId;
	}
	public void seteId(String eId) {
		this.eId = eId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getRatings() {
		return ratings;
	}
	public void setRatings(int ratings) {
		this.ratings = ratings;
	}
	@Override
	public String toString() {
		return "HrBean [eId=" + eId + ", password=" + password + ", ratings=" + ratings + "]";
	}
}