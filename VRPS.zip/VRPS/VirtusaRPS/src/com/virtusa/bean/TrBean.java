package com.virtusa.bean;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
@WebServlet("/TrBean")
public class TrBean extends HttpServlet {
	String eId;
	private String password;
	int techselect;
	public String geteId() {
		return eId;
	}
	public void seteId(String eId) {
		this.eId = eId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getTechselect() {
		return techselect;
	}
	public void setTechselect(int techselect) {
		this.techselect = techselect;
	}
	@Override
	public String toString() {
		return "TrBean [eId=" + eId + ", password=" + password + ", techselect=" + techselect + "]";
	}
}