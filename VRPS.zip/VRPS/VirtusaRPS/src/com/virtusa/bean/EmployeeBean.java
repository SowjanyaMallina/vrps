package com.virtusa.bean;


import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;


@WebServlet("/EmployeeBean")
public class EmployeeBean extends HttpServlet
{
	private int percentage;
	private String eId;
	private String password;
	private String skills;
	public int getPercentage() {
		return percentage;
	}
	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}
	public String geteId() {
		
		return eId;
	}
	public void seteId(String eId) {
		this.eId = eId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
	@Override
	public String toString() {
		return "EmployeeBean [percentage=" + percentage + ", eId=" + eId + ", password=" + password + ", skills="
				+ skills + "]";
	}
	}

