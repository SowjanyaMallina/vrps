package com.virtusa.bean;

public class RatingBean {
	private String rate;
	  public RatingBean(String rate)
	  {
		  this.rate=rate;
		  
	  }
	public String getRate() {
		return rate;
	}
	public void setRate(String rate) {
		this.rate = rate;
	}
	  
}
