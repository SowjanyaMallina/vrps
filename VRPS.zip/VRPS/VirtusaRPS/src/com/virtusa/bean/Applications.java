package com.virtusa.bean;

public class Applications
{
  private int aid;
  private int percentage;
  private String name;
  private String skills;
  private String currentdesg;
  public Applications(int aid,String name,String skills,String currentdesg,int percentage)
  {
	  this.aid=aid;
	  this.name=name;
	  this.skills=skills;
	  this.currentdesg=currentdesg;
	  this.percentage=percentage;
  }
public int getAid() {
	return aid;
}
public void setAid(int aid) {
	this.aid = aid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getSkills() {
	return skills;
}
public void setSkills(String skills) {
	this.skills = skills;
}
public String getCurrentdesg() {
	return currentdesg;
}
public void setCurrentdesg(String currentdesg) {
	this.currentdesg = currentdesg;
}
public int getPercentage() {
	return percentage;
}
public void setPercentage(int percentage) {
	this.percentage = percentage;
}
}
